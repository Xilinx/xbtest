<!--
# Copyright (C) 2022 Xilinx, Inc.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
-->

# xbtest-common xbtest package

Xilinx Inc xbtest-common v2.0 xbtest package.

 Built on Tue Apr 12 2022.

 Built from source CL 3522770.

 Built with Ubuntu version 18.04 and architecture amd64.


## Package info

The following table presents xclbin package information:

| Version | Release number | Distribution ID | Distribution release | Architecture | Build date |
|---|---|---|---|---|---|
| 2.0 | 3522770 | Ubuntu | 18.04 | amd64 | Tue Apr 12 2022 |

## Host application info

The following table presents host application build information:

| Build number | Build date |
|---|---|
| 3522770 | Tue Apr 12 19:09:19  2022 |
