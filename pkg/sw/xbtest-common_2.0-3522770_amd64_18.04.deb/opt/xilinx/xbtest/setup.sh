#!/bin/bash

# Copyright (C) 2022 Xilinx, Inc.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Script to setup environment for xbtest
# This script is installed in /opt/xilinx/xbtest and must
# be sourced from that location

# Check OS version requirement
OSDIST=`lsb_release -i |awk -F: '{print tolower($2)}' | tr -d ' \t'`
OSREL=`lsb_release -r |awk -F: '{print tolower($2)}' |tr -d ' \t' | awk -F. '{print $1*100+$2}'`

if [[ $OSDIST == "ubuntu" ]]; then
    if (( $OSREL < 1604 )); then
        echo "ERROR: Ubuntu release version must be 16.04 or later"
        return 1
    fi
fi

if [[ $OSDIST == "centos" ]] || [[ $OSDIST == "redhat"* ]]; then
    if (( $OSREL < 704 )); then
        echo "ERROR: Centos or RHEL release version must be 7.4 or later"
        return 1
    fi
fi

XILINX_XBTEST=$(readlink -f $(dirname ${BASH_SOURCE[0]}))

if [[ $XILINX_XBTEST != *"/opt/xilinx/xbtest" ]]; then
    echo "Invalid location: $XILINX_XBTEST"
    echo "This script must be sourced from xbtest install directory: /opt/xilinx/xbtest"
    return 1
fi

export XILINX_XBTEST
export PATH=$XILINX_XBTEST/bin:$PATH

echo "XILINX_XBTEST : $XILINX_XBTEST"
echo "PATH          : $PATH"
